<html>
<head>
</head>
<body>
<script language="JavaScript" type="text/javascript">

var pagina="https://viveweb.com.co/decathlon/inicio.php"
function redireccionar() 
{
location.href=pagina
} 
setTimeout ("redireccionar()", 1000);

</script>
</body>
</html>